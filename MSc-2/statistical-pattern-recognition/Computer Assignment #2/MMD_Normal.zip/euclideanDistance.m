function Eucl = euclideanDistance(x, y)
Eucl = sqrt(sum((x - y).^2));
end